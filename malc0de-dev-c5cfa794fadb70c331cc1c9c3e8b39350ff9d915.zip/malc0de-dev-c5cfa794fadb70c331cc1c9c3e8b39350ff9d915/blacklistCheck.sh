#!/bin/bash
# Trivial script to download the latest malc0de blacklist and see if
# AS3741 is involved in anything nasty here.
# Oh yes, and all ZA ones too haha

reverseIp() {
   echo "$1" | awk 'BEGIN{FS=".";ORS="."} {for (i = NF; i > 0; i--){print $i}}'
}
export -f reverseIp

work() {
   echo "Downloading blacklist..."
   wget http://malc0de.com/bl/IP_Blacklist.txt
   echo "Doing ASN resolves..."
   while read line; do echo $line; done < IP_Blacklist.txt | awk '{ print "result=`reverseIp " $1 "`; cymru=\"origin.asn.cymru.com TXT\"; echo -ne " $1 "; echo -ne \" \"; dig +short $result$cymru;" }' | sh > results.dns
   echo " - output is in results.dns now"
   echo ""
   echo "Grepping the output for ASN 3741..."
   echo ""
   cat results.dns | grep 3741
   echo ""
   echo "Looking for bad ZA stuff in the blacklist.."
   cat results.dns | grep ZA | cut -d '"' -f 2 | awk '{ print "dig +short AS" $1 ".asn.cymru.com TXT" }' | sort | uniq | sh | tee zaasn.dns
   echo " - output is in zaasn.dns now"
   echo ""
   echo ""
   echo "And now the mini report :)"
   cat zaasn.dns | sort | uniq | cut -d '"' -f 2 | awk '{ print "asnname=\"" $9 "\"; asnnumber=\"" $1 "\"; echo -ne \"Network Name: \" $asnname \" \";cat results.dns | grep $asnnumber " }' | sh | grep "Network Name" > report.dns
   cat report.dns | awk '{ print $1 " " $2 " " $3 " " $4 " " $6 " " $7 " " $8 " " $9 " " $10 " " $11 " " $12 " " $13 " " $14 " See: http://malc0de.com/database/index.php?search=" $4 "&IP=on" }' | tr -d '"'
   echo ""
   echo "Done"
}

# - main script there.. err here xD
rundate=`date`
echo "Started on $rundate"
echo ""
if [ ! -f IP_Blacklist.txt ];
then
   work
else
   echo "Removing old blacklist.."
   rm -rf IP_Blacklist.txt
   echo "Done"
   work
fi
