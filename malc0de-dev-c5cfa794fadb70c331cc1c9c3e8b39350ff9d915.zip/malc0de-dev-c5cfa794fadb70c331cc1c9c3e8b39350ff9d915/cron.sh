#!/bin/bash

# - hacky tacky script to run the terribad bash and mail the shit
HOME='/usr/local/malc0de/'
MAILDST='risk@is.co.za'

cd $HOME
w="logs/"; s=`date +%F-%H-%M-%S`; log=-log.log; ./blacklistCheck.sh &> $w$s$log
cat $w$s$log | mail -s "malc0de" $MAILDST
